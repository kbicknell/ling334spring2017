################
# Bozena Pajak #
# 5/4/2015     #
################


def countsToProbs(countsVector):
    """ This function takes as input a vector of counts,
    transforms them into probabilities, and outputs a vector
    of probabilities. """
    vectorSum = sum(countsVector)
    probsVector = []
    for count in countsVector:
        probsVector.append(float(count)/vectorSum)
    return(probsVector)
