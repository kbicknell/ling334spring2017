################
# Bozena Pajak #
# 5/4/2015     #
################


""" This program combines individual subject files into one file. """

# enter number of subjects
numOfSubj = 3


# define input and output files
exptFile = '2.data/X.txt'
outputFile = '2.data/allResults.txt'


# open output file and write header
wf = open(outputFile, 'w')
wf.write('Subject' + '\t' + 'Trial' + '\t' + 'SoundFile' + '\t' + 'LeftPic' + '\t' + 'RightPic' + '\t' + 'RT' + '\t' + 'Response' + '\n')


# loop through individual subject files
for subj in range(1, numOfSubj+1):
    exptFile_path = exptFile.replace('X', str(subj))
    rf = open(exptFile_path, 'U')

    # get expt data for this subject & write it to the output file
    for i, line in enumerate(rf, start = 1):
        wf.write(str(subj) + '\t' + str(i) + '\t' + line)
    
    rf.close()
  
wf.close()
