################
# Bozena Pajak #
# 5/4/2015     #
################


""" This program saves subject survey data in a dictionary. """

# define input and output files
surveyFile = '4.data/survey_info.txt'

rf = open(surveyFile, 'U')

# store survey info in a dictionary with subject number as a key and the rest as the value
surveyDict = {}

for line in rf:
    line = line.strip().split('\t')
    subjNum = line[0]
    subjGender = line[1]
    subjAge = line[2]
    subjL1 = line[3]
    subjL2 = line[4]
    
    # check survey input
    assert len(subjGender) == 1, "Invalid gender for subject # %s!" % subjNum
    assert int(subjAge) >= 18, "Subject # %s is under 18!" % subjNum
    assert subjL1 == 'English', "Subject # %s is a native speaker of %s!" % (subjNum, subjL1)
    
    subjInfo = ','.join(line[1:])
    surveyDict[subjNum] = subjInfo
    
rf.close()

