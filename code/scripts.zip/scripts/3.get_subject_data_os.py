################
# Bozena Pajak #
# 5/4/2015     #
################


""" This program combines individual subject files into one file. """

import os

# define input and output files
directory='2.data/'
exptFiles = os.listdir(directory)
outputFile = '2.data/allResults_os.txt'


# open output file and write header
wf = open(outputFile, 'w')
wf.write('Subject' + '\t' + 'Trial' + '\t' + 'SoundFile' + '\t' + 'LeftPic' + '\t' + 'RightPic' + '\t' + 'RT' + '\t' + 'Response' + '\n')


# loop through individual subject files
for fileName in exptFiles:
    if fileName[0].isdigit(): # only read subject files
        rf = open(directory+fileName, 'U')
        splitFileName = fileName.split('.')
        subj = splitFileName[0]
    
        # get expt data for this subject & write it to the output file
        for i, line in enumerate(rf, start = 1):
            wf.write(subj + '\t' + str(i) + '\t' + line)
    
        rf.close()
  
wf.close()
