################
# Bozena Pajak #
# 5/4/2015     #
################


def countsToProbs(countsVector):
    """ This function takes as input a vector of counts, and transforms them into probabilities. """
    vectorSum = sum(countsVector)
    probsVector = []
    for count in countsVector:
        probsVector.append(float(count)/vectorSum)
    return(probsVector)


def multiSplit(seq, seps): 
    """ Splits a string sequence by multiple separators. It takes as
    input a string seq and a list of separators seps, and outputs a list of
    items resulting from the split."""
    splitSeq = [seq]
    for sep in seps:
        seq, splitSeq = splitSeq, []
        for item in seq:
            splitSeq += item.split(sep)
    return(splitSeq)

